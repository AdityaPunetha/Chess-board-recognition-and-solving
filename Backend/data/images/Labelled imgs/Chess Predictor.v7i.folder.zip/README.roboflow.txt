
Chess Predictor - v7 2022-01-30 2:56pm
==============================

This dataset was exported via roboflow.ai on January 30, 2022 at 9:26 AM GMT

It includes 92 images.
Chess-pieces are annotated in folder format.

The following pre-processing was applied to each image:
* Resize to 100x100 (Stretch)
* Grayscale (CRT phosphor)

No image augmentation techniques were applied.


