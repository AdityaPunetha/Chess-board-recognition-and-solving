
Chess Predictor - v10 2022-02-02 2:29pm
==============================

This dataset was exported via roboflow.ai on February 2, 2022 at 9:00 AM GMT

It includes 92 images.
Chess-pieces are annotated in folder format.

The following pre-processing was applied to each image:
* Resize to 100x100 (Stretch)
* Grayscale (CRT phosphor)

No image augmentation techniques were applied.


